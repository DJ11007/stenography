import test from "node:test";
import assert from "node:assert/strict";
import { ENGLISH_LESSONS, EXAM_PRESETS, getExamPreset, getLesson, isLessonUnlocked } from "../lib/typing-curriculum.ts";

test("English curriculum covers every Phase 2 lesson category in order", () => {
  assert.deepEqual(ENGLISH_LESSONS.map((lesson) => lesson.category), ["home-row", "upper-row", "lower-row", "capitals", "numbers", "punctuation", "passages"]);
  assert.deepEqual(ENGLISH_LESSONS.map((lesson) => lesson.order), [1, 2, 3, 4, 5, 6, 7]);
  assert.equal(new Set(ENGLISH_LESSONS.map((lesson) => lesson.id)).size, ENGLISH_LESSONS.length);
});

test("every lesson has configurable accuracy and both learning modes", () => {
  for (const lesson of ENGLISH_LESSONS) {
    assert.ok(lesson.unlockAccuracy >= 1 && lesson.unlockAccuracy <= 100);
    assert.ok(lesson.content.length > 0);
    assert.ok(lesson.timedContent.length > 0);
    assert.equal(getLesson(lesson.id)?.id, lesson.id);
  }
});

test("RSSB catalogue exposes independent English and Hindi presets", () => {
  assert.deepEqual(EXAM_PRESETS.filter((preset) => preset.category === "typing").map((preset) => preset.language), ["English", "Hindi"]);
  assert.deepEqual(EXAM_PRESETS.filter((preset) => preset.category === "stenography").map((preset) => preset.language), ["English", "Hindi"]);
  for (const preset of EXAM_PRESETS) {
    assert.ok(preset.durationSeconds > 0);
    assert.ok(preset.speedRequirement > 0);
    assert.ok(preset.accuracyRequirement > 0);
    assert.ok(preset.passage.length > 0);
    assert.match(preset.subtitle, /independent.*practice simulation/i);
    assert.equal(getExamPreset(preset.slug)?.id, preset.id);
    assert.ok(preset.script && preset.inputEncoding && preset.fontStack && preset.keyboardLayout);
    assert.ok(preset.inputSystems.length > 0);
  }
  assert.notEqual(getExamPreset("english-stenography")?.passage, getExamPreset("hindi-stenography")?.passage);
});

test("lesson unlocks cannot be bypassed by a direct lesson id", () => {
  assert.equal(isLessonUnlocked("home-row", {}), true);
  assert.equal(isLessonUnlocked("upper-row", {}), false);
  assert.equal(isLessonUnlocked("upper-row", { "home-row": { lessonId: "home-row", completed: true, bestAccuracy: 95, bestWpm: 20, attempts: 1, weakKeys: [] } }), true);
  assert.equal(isLessonUnlocked("missing-lesson", {}), false);
});
