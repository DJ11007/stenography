import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

const workspace = readFileSync(new URL("../app/typing/_components/configurable-typing-exam.tsx", import.meta.url), "utf8");

test("active workspace orders original passage, controls, and typing area in one window", () => {
  const original = workspace.indexOf('id="original-passage-title"');
  const controls = workspace.indexOf('aria-label="Typing controls"');
  const typing = workspace.indexOf('id="typing-passage-title"');
  assert.ok(original >= 0 && original < controls && controls < typing);
  assert.match(workspace, /grid-rows-\[minmax\(0,1fr\)_auto_minmax\(0,1fr\)\]/);
  for (const label of ["Original Passage", "Type Here", "Duration", "Submit", "Pause", "Auto Scroll", "Show Scrollbar"]) assert.ok(workspace.includes(label));
  assert.match(workspace, /aria-label=\{`\$\{formatTime\(timeLeft\)\} remaining`\}/);
});

test("workspace is viewport constrained with independently scrollable min-height-zero panels", () => {
  assert.match(workspace, /h-\[100dvh\] min-h-0 flex-col overflow-hidden/);
  assert.match(workspace, /min-h-0 w-full max-w-\[1500px\] flex-1 overflow-auto/);
  assert.match(workspace, /min-h-\[40rem\]/);
  assert.match(workspace, /className="min-h-0 flex-1 p-4/);
  assert.match(workspace, /className="min-h-0 w-full flex-1 resize-none overflow-y-auto/);
});

test("auto-scroll writes only the two panel scroll positions and never scrolls the page", () => {
  assert.match(workspace, /if \(!autoScroll \|\| paused\)/);
  assert.match(workspace, /original\.scrollTop = originalTarget/);
  assert.match(workspace, /typing\.scrollTop = typingTarget/);
  assert.doesNotMatch(workspace, /scrollIntoView|window\.scroll|document\.documentElement\.scroll|document\.body\.scroll/);
});

test("locked passage scrolling restores manual movement and cleans up every listener", () => {
  assert.match(workspace, /lockedPassageScrollTop\.current/);
  for (const event of ["scroll", "wheel", "touchmove", "keydown"]) {
    assert.match(workspace, new RegExp(`original\\.addEventListener\\("${event}"`));
    assert.match(workspace, new RegExp(`original\\.removeEventListener\\("${event}"`));
  }
  assert.match(workspace, /\[autoScroll, paused\]/);
});

test("pause stops movement and input while resume restores the active position", () => {
  assert.match(workspace, /if \(!started \|\| finished \|\| paused \|\| !endTimestamp\) return/);
  assert.match(workspace, /disabled=\{fontAvailable !== true \|\| paused\}/);
  assert.match(workspace, /setEndTimestamp\(Date\.now\(\) \+ timeLeft \* 1000\); setPaused\(false\)/);
  assert.match(workspace, /if \(!autoScroll \|\| paused\) \{ lastActiveLine\.current = null; return; \}/);
});

test("selected English, Hindi Unicode, and Kruti Dev fonts and language metadata remain active", () => {
  assert.equal(workspace.match(/fontFamily: inputSystem\.fontStack/g)?.length, 2);
  assert.equal(workspace.match(/inputSystem\.language === "Hindi" \? "hi" : "en"/g)?.length, 2);
  assert.match(workspace, /normalizeTypingInput\(typedText, inputSystem\)/);
  assert.match(workspace, /getInputSystemPassage\(inputSystem, preset\.passage\)/);
});

test("shared English and Hindi exam timers wait for the first typing input", () => {
  assert.match(workspace, /setEndTimestamp\(null\); setTimerStarted\(false\)/);
  assert.match(workspace, /onFirstTypingInput=\{beginTiming\}/);
  assert.match(workspace, /if \(value !== typedText\) onFirstTypingInput\(\)/);
  assert.match(workspace, /Timer starts on your first keystroke/);
});
