import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { decideSignInDestination, safeAuthenticatedNext } from "../lib/auth-routing.ts";

test("an invalid application role is denied on the admin login surface", () => {
  assert.deepEqual(decideSignInDestination("admin", null, null), { type: "deny-admin" });
  assert.deepEqual(decideSignInDestination("admin", "student", "aal1"), { type: "deny-admin" });
});

test("an AAL2 administrator enters the admin panel", () => {
  assert.deepEqual(decideSignInDestination("admin", "admin", "aal2"), {
    type: "redirect",
    destination: "/admin",
  });
});

test("an AAL1 administrator is sent to the reachable MFA path", () => {
  assert.deepEqual(decideSignInDestination("admin", "admin", "aal1"), {
    type: "redirect",
    destination: "/account/security?next=/admin",
  });
});

test("account-security next paths are allowlisted", () => {
  assert.equal(safeAuthenticatedNext("/admin"), "/admin");
  assert.equal(safeAuthenticatedNext("https://evil.example"), undefined);
  assert.equal(safeAuthenticatedNext("//evil.example"), undefined);
});

test("login reuses the signed-in user and public login routes skip proxy session lookup", () => {
  const actions = readFileSync(new URL("../app/auth/actions.ts", import.meta.url), "utf8");
  const proxy = readFileSync(new URL("../proxy.ts", import.meta.url), "utf8");
  assert.match(actions, /const user = signInData\.user/);
  assert.doesNotMatch(actions, /signInWithPassword[\s\S]{0,300}auth\.getUser/);
  assert.match(proxy, /login\(\?:\/\|\$\)/);
  assert.match(proxy, /admin\/login\(\?:\/\|\$\)/);
});
