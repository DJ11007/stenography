import { signOut } from "@/app/auth/actions";
import { requireAdmin } from "@/lib/auth";
import Link from "next/link";

export default async function AdminPage() {
  const { user, profile } = await requireAdmin();
  return <main className="min-h-screen bg-slate-100 p-6"><div className="mx-auto max-w-5xl"><header className="flex items-center justify-between rounded-2xl bg-slate-900 p-6 text-white shadow"><div><p className="text-sm font-semibold text-blue-300">SAMRADHI CLASSES</p><h1 className="text-2xl font-bold">Admin panel</h1><p className="mt-1 text-slate-300">{profile?.full_name || user.email}</p></div><form action={signOut}><button className="rounded-lg bg-white px-4 py-2 font-semibold text-slate-800">Sign out</button></form></header><section className="mt-6 grid gap-5 md:grid-cols-3"><Link href="/admin/tests" className="block"><AdminCard title="Typing tests" text="Create, edit, publish, unpublish and delete typing tests." active /></Link><AdminCard title="Students" text="Student accounts and test history will be managed here." /><AdminCard title="Stenography & efficiency" text="This foundation will support dictation and practical computer tests later." /></section></div></main>;
}

function AdminCard({ title, text, active = false }: { title: string; text: string; active?: boolean }) { return <article className={`rounded-2xl bg-white p-6 shadow ${active ? "transition hover:-translate-y-1 hover:shadow-lg" : ""}`}><h2 className="text-lg font-bold">{title}</h2><p className="mt-2 text-sm leading-6 text-slate-600">{text}</p><span className={`mt-5 inline-block rounded-full px-3 py-1 text-xs font-bold ${active ? "bg-blue-100 text-blue-800" : "bg-amber-100 text-amber-800"}`}>{active ? "Manage tests →" : "Coming next"}</span></article>; }
