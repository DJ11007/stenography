"use server";

import { revalidatePath } from "next/cache";
import { requireAdmin } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { slugifyTest, validateManagedTest, type ManagedTestDraft, type ManagedTestStatus } from "@/lib/admin-tests";

export type TestFormState = { error?: string; success?: string };
const text = (data: FormData, name: string) => String(data.get(name) ?? "").trim();

function parseDraft(formData: FormData): ManagedTestDraft {
  const language = text(formData, "language") === "Hindi" ? "Hindi" : "English";
  const modeValue = text(formData, "mode");
  const mode = (["learn", "practice", "exam", "stenography"].includes(modeValue) ? modeValue : "practice") as ManagedTestDraft["mode"];
  const isLive = formData.get("isLive") === "on";
  const iso = (name: string) => { const value = text(formData, name); const date = value ? new Date(value) : null; return date && Number.isFinite(date.getTime()) ? date.toISOString() : value || null; };
  return {
    title: text(formData, "title"), description: text(formData, "description"), slug: slugifyTest(text(formData, "slug") || text(formData, "title")), language,
    inputSystemId: text(formData, "inputSystemId"), mode, durationSeconds: Number(formData.get("durationMinutes")) * 60,
    passage: String(formData.get("passage") ?? "").replace(/\r\n?/g, "\n"), requiredWpm: Number(formData.get("requiredWpm")), requiredAccuracy: Number(formData.get("requiredAccuracy")),
    backspaceMode: (["full", "word", "disabled"].includes(text(formData, "backspaceMode")) ? text(formData, "backspaceMode") : "full") as ManagedTestDraft["backspaceMode"],
    wordMethod: text(formData, "wordMethod") === "spaces" ? "spaces" : "characters",
    highlightMode: (["character", "word", "none"].includes(text(formData, "highlightMode")) ? text(formData, "highlightMode") : "character") as ManagedTestDraft["highlightMode"],
    visibility: text(formData, "visibility") === "public" ? "public" : "private",
    isLive, startsAt: isLive ? iso("startsAt") : null, endsAt: isLive ? iso("endsAt") : null, resultsPublishAt: isLive ? iso("resultsPublishAt") : null,
  };
}

export async function saveManagedTest(_: TestFormState, formData: FormData): Promise<TestFormState> {
  await requireAdmin(); const draft = parseDraft(formData); const validation = validateManagedTest(draft);
  if (validation.errors.length) return { error: validation.errors[0] };
  const payload = { title: draft.title, description: draft.description, slug: draft.slug, language: draft.language, input_system_id: draft.inputSystemId, mode: draft.mode, duration_seconds: draft.durationSeconds, passage: validation.passage, required_wpm: draft.requiredWpm, required_accuracy: draft.requiredAccuracy, backspace_mode: draft.backspaceMode, word_method: draft.wordMethod, highlight_mode: draft.highlightMode, visibility: draft.visibility, passage_characters: validation.characterCount, passage_words: validation.wordCount, is_live: draft.isLive, live_starts_at: draft.startsAt, live_ends_at: draft.endsAt, results_publish_at: draft.resultsPublishAt };
  const id = text(formData, "testId") || null; const publish = formData.get("intent") === "publish"; const supabase = await createClient();
  const { error } = await supabase.rpc("save_scheduled_managed_test", { p_test_id: id, p_payload: payload, p_publish: publish });
  if (error) return { error: error.code === "23505" ? "That URL slug is already in use." : "The test could not be saved. Confirm the migration is applied and your MFA session is verified." };
  revalidatePath("/admin/tests"); revalidatePath("/tests"); revalidatePath("/live-test"); revalidatePath("/");
  return { success: publish ? "A new immutable version was saved and published." : "A new immutable draft version was saved." };
}

export async function setManagedTestStatus(formData: FormData) { await requireAdmin(); const id=text(formData,"testId"); const value=text(formData,"status"); if(!id||!["draft","published","unpublished","archived"].includes(value))return; const supabase=await createClient(); await supabase.rpc("set_managed_test_status",{p_test_id:id,p_status:value as ManagedTestStatus}); revalidatePath("/admin/tests"); revalidatePath("/tests"); }
export async function duplicateManagedTest(formData: FormData) { await requireAdmin(); const id=text(formData,"testId"); if(!id)return; const supabase=await createClient(); await supabase.rpc("duplicate_managed_test",{p_test_id:id}); revalidatePath("/admin/tests"); }
export async function deleteManagedTest(formData: FormData) { await requireAdmin(); const id=text(formData,"testId"); if(!id)return; const supabase=await createClient(); await supabase.rpc("delete_managed_test_if_safe",{p_test_id:id}); revalidatePath("/admin/tests"); }
