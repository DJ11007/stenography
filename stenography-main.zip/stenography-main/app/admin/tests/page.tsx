import Link from "next/link";
import { requireAdmin } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import TestManager, { type ManagedTestRow } from "./test-manager";

export default async function AdminTestsPage() {
  await requireAdmin(); const supabase = await createClient();
  const { data: tests } = await supabase.from("tests").select("id,title,slug,description,language,status,mode,input_system_id,visibility,duration_seconds,current_version_id,current_version_number,updated_at,is_live,live_starts_at,live_ends_at,results_publish_at").order("updated_at",{ascending:false});
  const ids=(tests??[]).map((test)=>test.id); const versionIds=(tests??[]).flatMap((test)=>test.current_version_id?[test.current_version_id]:[]);
  const [{data:versions},{data:attempts}] = await Promise.all([
    versionIds.length ? supabase.from("test_versions").select("*").in("id",versionIds) : Promise.resolve({data:[]}),
    ids.length ? supabase.from("test_attempts").select("test_id").in("test_id",ids) : Promise.resolve({data:[]}),
  ]);
  const versionMap=new Map((versions??[]).map((version)=>[version.id,version])); const attemptCounts=new Map<string,number>();
  for(const attempt of attempts??[]) attemptCounts.set(attempt.test_id,(attemptCounts.get(attempt.test_id)??0)+1);
  const rows=(tests??[]).map((test)=>({...test,currentVersion:test.current_version_id?versionMap.get(test.current_version_id)??null:null,attempts:attemptCounts.get(test.id)??0})) as ManagedTestRow[];
  return <main className="min-h-screen bg-slate-100 p-4 sm:p-6"><div className="mx-auto max-w-[1500px]"><header className="mb-6"><Link href="/admin" className="text-sm font-semibold text-blue-700">← Admin dashboard</Link><h1 className="mt-2 text-3xl font-black">Test management</h1><p className="mt-1 text-slate-600">Versioned tests, controlled publishing, visibility and immutable attempt snapshots.</p></header><TestManager tests={rows}/></div></main>;
}
