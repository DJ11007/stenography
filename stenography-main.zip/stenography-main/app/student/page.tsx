import Link from "next/link";
import { signOut } from "@/app/auth/actions";
import { requireUser } from "@/lib/auth";

export default async function StudentPage() {
  const user = await requireUser();
  return <main className="min-h-screen bg-slate-100 p-6"><div className="mx-auto max-w-4xl"><header className="flex items-center justify-between rounded-2xl bg-white p-6 shadow"><div><p className="text-sm font-semibold text-blue-700">SAMRADHI CLASSES</p><h1 className="text-2xl font-bold">Student dashboard</h1><p className="mt-1 text-slate-600">{user.email}</p></div><form action={signOut}><button className="rounded-lg border border-slate-300 px-4 py-2 font-semibold">Sign out</button></form></header><section className="mt-6 rounded-2xl bg-white p-6 shadow"><h2 className="text-xl font-bold">Your test history</h2><p className="mt-2 text-slate-600">Your completed typing-test results will appear here after the next milestone.</p><Link href="/typing" className="mt-5 inline-block rounded-lg bg-blue-700 px-5 py-3 font-semibold text-white">Browse tests</Link></section></div></main>;
}
