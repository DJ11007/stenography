import Link from "next/link";
import Image from "next/image";
import { AccessNavigation } from "@/app/_components/access-navigation";

export function TypingBrandHeader() {
  return <header className="bg-blue-700 text-white shadow"><div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-3"><Link href="/typing" className="flex min-w-0 items-center gap-3"><Image src="/samradhi-classes-logo.png" alt="Samradhi Classes logo" width={40} height={40} priority className="h-10 w-10 shrink-0 rounded-full bg-white object-contain ring-1 ring-white/80"/><span className="min-w-0"><strong className="block truncate text-lg">SAMRADHI CLASSES</strong><span className="hidden text-xs text-blue-100 sm:block">Learn • Practice • Simulate</span></span></Link><div className="flex items-center gap-2"><Link href="/typing" className="hidden rounded-lg border border-blue-300 px-3 py-2 text-sm font-bold hover:bg-blue-600 sm:block">Typing Hub</Link><AccessNavigation dark/></div></div></header>;
}
