import { notFound } from "next/navigation";
import { LessonWorkspace } from "../../_components/lesson-workspace";
import { getLesson } from "@/lib/typing-curriculum";

export default async function LessonPage({ params }: PageProps<"/typing/learn/[lessonId]">) {
  const lesson = getLesson((await params).lessonId);
  if (!lesson) notFound();
  return <LessonWorkspace lesson={lesson}/>;
}
