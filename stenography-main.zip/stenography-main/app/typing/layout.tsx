export default function TypingLayout({ children }: { children: React.ReactNode }) {
  return children;
}
