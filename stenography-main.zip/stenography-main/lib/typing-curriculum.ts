import type { BackspaceMode, HighlightMode, ScoringProfile, WordMethod } from "./typing-test";
import { KRUTI_DEV_FONT_ASSET, type InputEncoding, type InputSystem, type TypingLanguage, type TypingScript } from "./typing-language.ts";

export type TypingLessonCategory =
  | "home-row"
  | "upper-row"
  | "lower-row"
  | "capitals"
  | "numbers"
  | "punctuation"
  | "passages";

export type TypingLesson = {
  id: string;
  order: number;
  title: string;
  shortDescription: string;
  category: TypingLessonCategory;
  targetKeys: string[];
  content: string;
  timedContent: string;
  unlockAccuracy: number;
};

export type LessonProgress = {
  lessonId: string;
  completed: boolean;
  bestAccuracy: number;
  bestWpm: number;
  attempts: number;
  weakKeys: string[];
};

export type ExamPreset = {
  id: string;
  slug: string;
  title: string;
  subtitle: string;
  category: "typing" | "stenography";
  language: TypingLanguage;
  script: TypingScript;
  inputEncoding: InputEncoding;
  durationSeconds: number;
  passage: string;
  fontLabel: string;
  fontStack: string;
  fontClassName: string;
  layoutLabel: string;
  keyboardLayout: string;
  inputSystems: InputSystem[];
  speedRequirement: number;
  accuracyRequirement: number;
  backspaceMode: BackspaceMode;
  wordMethod: WordMethod;
  highlightMode?: HighlightMode;
  scoringProfile: ScoringProfile;
  marksMethod?: {
    id: "configured-rssb-ldc";
    maximumMarks: number;
    minimumPassingMarks: number;
    marksPerCorrectWord: number;
    requiredDurationSeconds: number;
    passageWordLimit: number;
  };
};

function repeatPassageToExactWordCount(passage: string, wordCount: number) {
  const sourceWords = passage.trim().split(/\s+/u);
  if (!sourceWords.length) throw new Error("A configured typing passage cannot be empty.");
  return Array.from({ length: wordCount }, (_, index) => sourceWords[index % sourceWords.length]).join(" ");
}

export const ENGLISH_QWERTY: InputSystem = { id: "english-qwerty", label: "English — QWERTY", language: "English", script: "Latin", inputEncoding: "unicode", fontLabel: "System English", fontStack: "Arial, Helvetica, sans-serif", keyboardLayout: "QWERTY keyboard" };
export const HINDI_UNICODE_MANGAL: InputSystem = { id: "hindi-unicode-mangal", label: "Hindi Unicode — Mangal/Nirmala UI", language: "Hindi", script: "Devanagari", inputEncoding: "unicode", fontLabel: "Mangal / Nirmala UI", fontStack: '"Nirmala UI", Mangal, "Noto Sans Devanagari", sans-serif', keyboardLayout: "Unicode Hindi phonetic/default layout" };
export const HINDI_UNICODE_REMINGTON: InputSystem = { ...HINDI_UNICODE_MANGAL, id: "hindi-unicode-remington", label: "Hindi Unicode — Remington layout", keyboardLayout: "Remington Unicode layout" };
export const HINDI_UNICODE_INSCRIPT: InputSystem = { ...HINDI_UNICODE_MANGAL, id: "hindi-unicode-inscript", label: "Hindi Unicode — InScript layout", keyboardLayout: "InScript Unicode layout" };
export const HINDI_KRUTI_DEV: InputSystem = { id: "hindi-krutidev-010", label: "Kruti Dev 010 — legacy encoding", language: "Hindi", script: "Devanagari", inputEncoding: "krutidev-legacy", fontLabel: "Kruti Dev 010 (licensed asset required)", fontStack: '"Kruti Dev 010", sans-serif', keyboardLayout: "Remington / Kruti Dev legacy layout", requiredFontAsset: KRUTI_DEV_FONT_ASSET, passageOverride: repeatPassageToExactWordCount("f'k{kk O;fDr ds thou esa egRoiw.kZ Hkwfedk fuHkkrh gSA fu;fer vH;kl ls Vkbfiax dh xfr vkSj 'kq)rk esa lq/kkj gksrk gSA", 400) };
export const HINDI_INPUT_SYSTEMS = [HINDI_UNICODE_MANGAL, HINDI_UNICODE_REMINGTON, HINDI_UNICODE_INSCRIPT, HINDI_KRUTI_DEV];

export const ENGLISH_LESSONS: TypingLesson[] = [
  { id: "home-row", order: 1, title: "Home Row Foundations", shortDescription: "Build a relaxed base with ASDF and JKL;.", category: "home-row", targetKeys: ["a", "s", "d", "f", "j", "k", "l", ";"], content: "asdf jkl; asdf jkl; fjdk sl;a asdf jkl;", timedContent: "ask dad; fall; flask; sad lad; all; ask;", unlockAccuracy: 90 },
  { id: "upper-row", order: 2, title: "Upper Row Reach", shortDescription: "Reach QWERTY and UIOP without moving your palms.", category: "upper-row", targetKeys: ["q", "w", "e", "r", "t", "y", "u", "i", "o", "p"], content: "qwer uiop type quiet power write route", timedContent: "write your report quite quickly with proper posture", unlockAccuracy: 90 },
  { id: "lower-row", order: 3, title: "Lower Row Control", shortDescription: "Train ZXCV and BNM with controlled downward reaches.", category: "lower-row", targetKeys: ["z", "x", "c", "v", "b", "n", "m"], content: "zxcv bnm, mix cabin move zinc zoom", timedContent: "move back calmly and examine every combination", unlockAccuracy: 90 },
  { id: "capitals", order: 4, title: "Capitals and Shift", shortDescription: "Coordinate the opposite Shift key with each hand.", category: "capitals", targetKeys: ["Shift", "A", "S", "D", "F", "J", "K", "L"], content: "Samradhi Classes Rajasthan English Delhi India", timedContent: "Samradhi Classes Helps Rajasthan Students Build Confidence", unlockAccuracy: 92 },
  { id: "numbers", order: 5, title: "Numbers", shortDescription: "Practice the number row for dates, marks and calculations.", category: "numbers", targetKeys: ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"], content: "12345 67890 2026 35 90 1500 10", timedContent: "Test 25 requires 35 WPM and 90 percent accuracy", unlockAccuracy: 92 },
  { id: "punctuation", order: 6, title: "Punctuation", shortDescription: "Add commas, periods, apostrophes and question marks.", category: "punctuation", targetKeys: [",", ".", ";", "'", "?", "!"], content: "Accuracy, speed, rhythm; practice. Don't rush!", timedContent: "Ready, steady, type! Accuracy matters; speed follows.", unlockAccuracy: 94 },
  { id: "full-passages", order: 7, title: "Full Passages", shortDescription: "Combine every row in complete exam-style sentences.", category: "passages", targetKeys: [], content: "Regular typing practice improves accuracy, rhythm, confidence, and speed. Keep your eyes on the screen and allow each finger to return to its home-row position.", timedContent: "Candidates should type with a steady rhythm and review their errors after every practice session. Consistent, accurate movement develops dependable speed for competitive examinations.", unlockAccuracy: 95 },
];

const ENGLISH_PASSAGE = `Education and regular practice play an important role in success in competitive examinations. A candidate who prepares with discipline can gradually improve knowledge, confidence, typing speed, accuracy, and time management. In a typing examination, speed alone is not enough because unnecessary mistakes can reduce the final performance. Students should therefore develop correct keyboard habits and learn to type without looking at the keyboard whenever possible. Regular practice also helps students understand common spelling mistakes, punctuation, spacing, and the correct use of capital letters. A good typing practice routine should begin with accuracy and then gradually increase speed. Candidates should sit comfortably, keep their fingers in the correct position, and maintain a steady rhythm while typing. They should avoid unnecessary movement and should not become nervous when they make a mistake. Continuous practice with different passages can improve concentration and help candidates become familiar with words of different lengths. Competitive examinations often require candidates to complete a task within a fixed period. Time management therefore becomes an important part of preparation. Students should regularly take timed tests and carefully examine their results after every test. The result should not be judged only by gross speed. Accuracy, errors, correct characters, incorrect characters, and net speed are also important indicators of performance. A disciplined student can improve gradually by identifying weak areas and working on them every day. Reading newspapers, books, articles, and educational material can also improve vocabulary and familiarity with sentence structures. However, typing practice should remain consistent because speed develops through repeated and correct keyboard movement. The objective of a typing test is to measure practical typing ability under a limited time condition. Candidates should remain calm, read the passage carefully, and maintain a comfortable rhythm throughout the examination. Regular mock tests can help students understand the test environment and reduce unnecessary pressure on the examination day. With patience, consistent practice, and careful analysis of mistakes, students can steadily improve their typing performance and become better prepared for competitive examinations.`;

const HINDI_PASSAGE = `शिक्षा व्यक्ति के जीवन में महत्वपूर्ण भूमिका निभाती है। नियमित अभ्यास से विद्यार्थियों में आत्मविश्वास और कार्य करने की क्षमता बढ़ती है। प्रतियोगी परीक्षाओं की तैयारी करने वाले विद्यार्थियों के लिए सही दिशा में किया गया अभ्यास बहुत उपयोगी होता है। टाइपिंग परीक्षा में गति के साथ शुद्धता का भी विशेष महत्व है। इसलिए अभ्यर्थी को पहले सही टाइप करना सीखना चाहिए और उसके बाद धीरे धीरे अपनी गति बढ़ानी चाहिए। नियमित परीक्षण से गलतियों को समझने और उन्हें सुधारने में सहायता मिलती है।`;

const ENGLISH_STENO_PASSAGE = `The committee met in the morning to review the public service report. The chairperson requested a clear record of every recommendation, financial estimate, and deadline. Members agreed that accurate transcription is essential because even a small change can alter the meaning of an official statement.`;
const HINDI_STENO_PASSAGE = `समिति ने जनसेवा से संबंधित प्रतिवेदन पर विचार करने के लिए प्रातः बैठक की। अध्यक्ष ने प्रत्येक सुझाव, अनुमान और समय सीमा का स्पष्ट अभिलेख तैयार करने का निर्देश दिया। सदस्यों ने माना कि शुद्ध प्रतिलेखन आवश्यक है क्योंकि छोटी त्रुटि भी कथन का अर्थ बदल सकती है।`;

const profile = (speed: number): ScoringProfile => ({ fullErrorPenalty: 1, halfErrorPenalty: 0.5, minorSpellingMaxDistance: 1, passNetWpm: speed, passAccuracy: 90 });
const preset = (value: Omit<ExamPreset, "script" | "inputEncoding" | "fontLabel" | "fontStack" | "fontClassName" | "layoutLabel" | "keyboardLayout">): ExamPreset => {
  const system = value.inputSystems[0];
  if (value.marksMethod) {
    const passageWords = value.passage.trim().split(/\s+/u).length;
    const overrideCounts = value.inputSystems.filter((item) => item.passageOverride).map((item) => item.passageOverride!.trim().split(/\s+/u).length);
    if (value.durationSeconds !== value.marksMethod.requiredDurationSeconds || passageWords !== value.marksMethod.passageWordLimit || overrideCounts.some((count) => count !== value.marksMethod!.passageWordLimit)) throw new Error(`Invalid ${value.id} marks-method preset configuration.`);
  }
  return { ...value, script: system.script, inputEncoding: system.inputEncoding, fontLabel: system.fontLabel, fontStack: system.fontStack, fontClassName: "font-sans", layoutLabel: system.keyboardLayout, keyboardLayout: system.keyboardLayout };
};

const RSSB_ENGLISH_MARKS_METHOD = { id: "configured-rssb-ldc", maximumMarks: 25, minimumPassingMarks: 9, marksPerCorrectWord: 0.05, requiredDurationSeconds: 600, passageWordLimit: 500 } as const;
const RSSB_HINDI_MARKS_METHOD = { id: "configured-rssb-ldc", maximumMarks: 25, minimumPassingMarks: 9, marksPerCorrectWord: 0.0625, requiredDurationSeconds: 600, passageWordLimit: 400 } as const;

export const EXAM_PRESETS: ExamPreset[] = [
  preset({ id: "rssb-ldc-english", slug: "rssb-ldc-english", title: "RSSB LDC English", subtitle: "Independent practice simulation", category: "typing", language: "English", durationSeconds: 600, passage: repeatPassageToExactWordCount(ENGLISH_PASSAGE, 500), inputSystems: [ENGLISH_QWERTY], speedRequirement: 35, accuracyRequirement: 90, backspaceMode: "full", wordMethod: "characters", scoringProfile: profile(35), marksMethod: RSSB_ENGLISH_MARKS_METHOD }),
  preset({ id: "rssb-ldc-hindi", slug: "rssb-ldc-hindi", title: "RSSB LDC Hindi", subtitle: "Independent practice simulation", category: "typing", language: "Hindi", durationSeconds: 600, passage: repeatPassageToExactWordCount(HINDI_PASSAGE, 400), inputSystems: HINDI_INPUT_SYSTEMS, speedRequirement: 30, accuracyRequirement: 90, backspaceMode: "full", wordMethod: "characters", scoringProfile: profile(30), marksMethod: RSSB_HINDI_MARKS_METHOD }),
  preset({ id: "english-stenography", slug: "english-stenography", title: "English Stenography", subtitle: "Independent stenography practice simulation", category: "stenography", language: "English", durationSeconds: 600, passage: ENGLISH_STENO_PASSAGE, inputSystems: [ENGLISH_QWERTY], speedRequirement: 80, accuracyRequirement: 90, backspaceMode: "full", wordMethod: "characters", scoringProfile: profile(80) }),
  preset({ id: "hindi-stenography", slug: "hindi-stenography", title: "Hindi Stenography", subtitle: "Independent stenography practice simulation", category: "stenography", language: "Hindi", durationSeconds: 600, passage: HINDI_STENO_PASSAGE, inputSystems: HINDI_INPUT_SYSTEMS, speedRequirement: 70, accuracyRequirement: 90, backspaceMode: "full", wordMethod: "characters", scoringProfile: profile(70) }),
];

export const getLesson = (id: string) => ENGLISH_LESSONS.find((lesson) => lesson.id === id);
export const getExamPreset = (id: string) => EXAM_PRESETS.find((preset) => preset.id === id || preset.slug === id);
export function isLessonUnlocked(lessonId: string, progress: Record<string, LessonProgress>) {
  const lessonIndex = ENGLISH_LESSONS.findIndex((lesson) => lesson.id === lessonId);
  if (lessonIndex <= 0) return lessonIndex === 0;
  return progress[ENGLISH_LESSONS[lessonIndex - 1].id]?.completed === true;
}
